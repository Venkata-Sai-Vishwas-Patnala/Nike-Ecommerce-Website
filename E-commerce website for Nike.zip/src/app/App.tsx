import { useState } from 'react';
import { Header } from './components/Header';
import { Hero } from './components/Hero';
import { ProductCard, Product } from './components/ProductCard';
import { Cart, CartItem } from './components/Cart';
import { Footer } from './components/Footer';

const products: Product[] = [
  {
    id: 1,
    name: 'Nike Air Max Pulse',
    category: "Men's Shoes",
    price: 13995,
    image: 'https://images.unsplash.com/photo-1542291026-7eec264c27ff?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=1080',
    colors: 2
  },
  {
    id: 2,
    name: 'Nike Air Force 1',
    category: "Men's Shoes",
    price: 8295,
    image: 'https://images.unsplash.com/photo-1595950653106-6c9ebd614d3a?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=1080',
    colors: 3
  },
  {
    id: 3,
    name: 'Nike Dunk Low Retro',
    category: "Men's Shoes",
    price: 8695,
    image: 'https://images.unsplash.com/photo-1606107557195-0e29a4b5b4aa?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=1080',
    colors: 1
  },
  {
    id: 4,
    name: 'Nike React Infinity',
    category: "Women's Running Shoe",
    price: 14995,
    image: 'https://images.unsplash.com/photo-1491553895911-0055eca6402d?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=1080',
    colors: 2
  },
  {
    id: 5,
    name: 'Nike Blazer Mid',
    category: "Women's Shoes",
    price: 9995,
    image: 'https://images.unsplash.com/photo-1600185365483-26d7a4cc7519?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=1080',
    colors: 4
  },
  {
    id: 6,
    name: 'Nike Court Vision',
    category: "Men's Shoes",
    price: 5695,
    image: 'https://images.unsplash.com/photo-1525966222134-fcfa99b8ae77?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=1080',
    colors: 2
  },
  {
    id: 7,
    name: 'Nike Air Jordan 1',
    category: "Men's Basketball Shoes",
    price: 12795,
    image: 'https://images.unsplash.com/photo-1600185365926-3a2ce3cdb9eb?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=1080',
    colors: 3
  },
  {
    id: 8,
    name: 'Nike Off-White',
    category: "Limited Edition",
    price: 19995,
    image: 'https://images.unsplash.com/photo-1543508282-6319a3e2621f?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=1080',
    colors: 1
  },
  {
    id: 9,
    name: 'Nike SB Dunk',
    category: "Men's Skateboarding Shoe",
    price: 11495,
    image: 'https://images.unsplash.com/photo-1549298916-b41d501d3772?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=1080',
    colors: 2
  },
  {
    id: 10,
    name: 'Nike Zoom Freak',
    category: "Basketball Shoes",
    price: 10995,
    image: 'https://images.unsplash.com/photo-1605348532760-6753d2c43329?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=1080',
    colors: 3
  },
  {
    id: 11,
    name: 'Nike Air Force 1 High',
    category: "Men's Shoes",
    price: 9695,
    image: 'https://images.unsplash.com/photo-1512374382149-233c42b6a83b?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=1080',
    colors: 2
  },
  {
    id: 12,
    name: 'Nike Pegasus Turbo',
    category: "Running Shoes",
    price: 15995,
    image: 'https://images.unsplash.com/photo-1600269452121-4f2416e55c28?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=1080',
    colors: 4
  }
];

export default function App() {
  const [cartItems, setCartItems] = useState<CartItem[]>([]);
  const [isCartOpen, setIsCartOpen] = useState(false);

  const handleAddToCart = (product: Product) => {
    setCartItems(prev => {
      const existing = prev.find(item => item.id === product.id);
      if (existing) {
        return prev.map(item =>
          item.id === product.id
            ? { ...item, quantity: item.quantity + 1 }
            : item
        );
      }
      return [...prev, { ...product, quantity: 1 }];
    });
    setIsCartOpen(true);
  };

  const handleUpdateQuantity = (id: number, quantity: number) => {
    setCartItems(prev =>
      prev.map(item =>
        item.id === id ? { ...item, quantity } : item
      )
    );
  };

  const handleRemoveItem = (id: number) => {
    setCartItems(prev => prev.filter(item => item.id !== id));
  };

  const cartItemCount = cartItems.reduce((sum, item) => sum + item.quantity, 0);

  return (
    <div className="min-h-screen bg-white">
      <Header
        cartItemCount={cartItemCount}
        onCartClick={() => setIsCartOpen(true)}
      />

      <Hero />

      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="flex items-center justify-between mb-8">
          <h2 className="text-2xl font-bold">Best of Air Max</h2>
          <div className="flex gap-2">
            <button className="text-sm px-4 py-2 border border-gray-300 rounded-full hover:border-gray-800">
              Shop
            </button>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {products.map(product => (
            <ProductCard
              key={product.id}
              product={product}
              onAddToCart={handleAddToCart}
            />
          ))}
        </div>
      </section>

      <section className="bg-gray-50 py-16 mt-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-4xl font-bold mb-6">FLIGHT ESSENTIALS</h2>
          <p className="text-lg text-gray-600 mb-8 max-w-2xl mx-auto">
            Your built-to-last, all-week wears—but with style only Jordan Brand can deliver.
          </p>
          <button className="bg-black text-white px-8 py-3 rounded-full hover:bg-gray-800 transition-colors">
            Shop
          </button>
        </div>
      </section>

      <Cart
        isOpen={isCartOpen}
        onClose={() => setIsCartOpen(false)}
        items={cartItems}
        onUpdateQuantity={handleUpdateQuantity}
        onRemoveItem={handleRemoveItem}
      />

      <Footer />
    </div>
  );
}